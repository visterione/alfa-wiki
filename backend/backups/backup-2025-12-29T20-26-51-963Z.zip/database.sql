--
-- PostgreSQL database dump
--

\restrict Dsh2kydzJVfAbu7bXuR01952hVPkLiaT1sPhwnRZmGSKYbZvGW1ErtVppCt4kc6

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enum_chat_members_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_chat_members_role AS ENUM (
    'admin',
    'member'
);


ALTER TYPE public.enum_chat_members_role OWNER TO postgres;

--
-- Name: enum_chats_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_chats_type AS ENUM (
    'private',
    'group'
);


ALTER TYPE public.enum_chats_type OWNER TO postgres;

--
-- Name: enum_messages_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_messages_type AS ENUM (
    'text',
    'image',
    'file',
    'system'
);


ALTER TYPE public.enum_messages_type OWNER TO postgres;

--
-- Name: enum_pages_contentType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_pages_contentType" AS ENUM (
    'wysiwyg',
    'html'
);


ALTER TYPE public."enum_pages_contentType" OWNER TO postgres;

--
-- Name: enum_sidebar_items_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_sidebar_items_type AS ENUM (
    'page',
    'divider',
    'link',
    'header'
);


ALTER TYPE public.enum_sidebar_items_type OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chat_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chat_members (
    id uuid NOT NULL,
    "chatId" uuid NOT NULL,
    "userId" uuid NOT NULL,
    role public.enum_chat_members_role DEFAULT 'member'::public.enum_chat_members_role,
    "lastReadAt" timestamp with time zone,
    "isNotificationMuted" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.chat_members OWNER TO postgres;

--
-- Name: chats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chats (
    id uuid NOT NULL,
    name character varying(255),
    type public.enum_chats_type DEFAULT 'private'::public.enum_chats_type,
    avatar character varying(500),
    "lastMessage" text,
    "lastMessageAt" timestamp with time zone,
    "createdBy" uuid,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.chats OWNER TO postgres;

--
-- Name: media; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media (
    id uuid NOT NULL,
    filename character varying(255) NOT NULL,
    "originalName" character varying(255),
    "mimeType" character varying(100),
    size integer,
    path character varying(1000) NOT NULL,
    "thumbnailPath" character varying(1000),
    alt character varying(500),
    description text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "uploadedBy" uuid
);


ALTER TABLE public.media OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id uuid NOT NULL,
    "chatId" uuid NOT NULL,
    "senderId" uuid NOT NULL,
    content text NOT NULL,
    type public.enum_messages_type DEFAULT 'text'::public.enum_messages_type,
    attachments jsonb DEFAULT '[]'::jsonb,
    "isEdited" boolean DEFAULT false,
    "replyToId" uuid,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: pages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pages (
    id uuid NOT NULL,
    slug character varying(255) NOT NULL,
    title character varying(500) NOT NULL,
    content text,
    "contentType" public."enum_pages_contentType" DEFAULT 'wysiwyg'::public."enum_pages_contentType",
    description text,
    keywords character varying(255)[] DEFAULT (ARRAY[]::character varying[])::character varying(255)[],
    "searchContent" text,
    icon character varying(50),
    "isPublished" boolean DEFAULT false,
    "isFavorite" boolean DEFAULT false,
    "allowedRoles" uuid[] DEFAULT ARRAY[]::uuid[],
    "customCss" text,
    "customJs" text,
    metadata jsonb DEFAULT '{}'::jsonb,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid
);


ALTER TABLE public.pages OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    permissions jsonb DEFAULT '{"pages": {"read": true, "admin": false, "write": false, "delete": false}}'::jsonb,
    "isSystem" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: search_index; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.search_index (
    id uuid NOT NULL,
    "entityType" character varying(50) NOT NULL,
    "entityId" uuid NOT NULL,
    title character varying(500),
    content text,
    keywords character varying(255)[] DEFAULT (ARRAY[]::character varying[])::character varying(255)[],
    url character varying(1000),
    metadata jsonb DEFAULT '{}'::jsonb,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.search_index OWNER TO postgres;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    key character varying(100) NOT NULL,
    value jsonb,
    description text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Name: sidebar_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sidebar_items (
    id uuid NOT NULL,
    type public.enum_sidebar_items_type DEFAULT 'page'::public.enum_sidebar_items_type,
    title character varying(255),
    icon character varying(50),
    "pageId" uuid,
    "externalUrl" character varying(1000),
    "parentId" uuid,
    "sortOrder" integer DEFAULT 0,
    "isExpanded" boolean DEFAULT false,
    "allowedRoles" uuid[] DEFAULT ARRAY[]::uuid[],
    "isVisible" boolean DEFAULT true,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.sidebar_items OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(255) NOT NULL,
    "displayName" character varying(100),
    email character varying(255),
    avatar character varying(500),
    "isActive" boolean DEFAULT true,
    "isAdmin" boolean DEFAULT false,
    "lastLogin" timestamp with time zone,
    settings jsonb DEFAULT '{}'::jsonb,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "roleId" uuid
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: chat_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chat_members (id, "chatId", "userId", role, "lastReadAt", "isNotificationMuted", "createdAt", "updatedAt") FROM stdin;
d1b6ba7c-107c-4f7d-82e5-02b49498366e	dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	9ce0c786-8eac-4103-8ec3-e1535de838d7	member	\N	f	2025-12-28 16:24:08.094+03	2025-12-28 16:24:08.094+03
f36b9df5-a72b-4f82-a9ec-25477fb7b189	c24d2dd9-286f-4e1b-bb21-67987b923544	40817c24-c657-4d2a-90ed-d5d4b016bd58	member	2025-12-29 07:06:36.205+03	f	2025-12-28 15:29:57.21+03	2025-12-29 07:06:36.205+03
a3d11c7e-bcfa-48c8-b43f-632b4c7518b7	dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	40817c24-c657-4d2a-90ed-d5d4b016bd58	member	2025-12-29 01:37:17.893+03	f	2025-12-29 01:02:06.574+03	2025-12-29 01:37:17.893+03
42e21e40-bee6-4a34-b31b-864447b0bc86	c24d2dd9-286f-4e1b-bb21-67987b923544	e00edd24-c594-4947-a10b-0c1decc45879	admin	2025-12-29 19:47:25.248+03	f	2025-12-28 15:29:57.21+03	2025-12-29 19:47:25.248+03
d1e98ef4-8a65-4c5f-8d08-e757c1763d69	dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	e00edd24-c594-4947-a10b-0c1decc45879	admin	2025-12-29 23:16:15.829+03	f	2025-12-28 16:04:11.431+03	2025-12-29 23:16:15.829+03
\.


--
-- Data for Name: chats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chats (id, name, type, avatar, "lastMessage", "lastMessageAt", "createdBy", "createdAt", "updatedAt") FROM stdin;
c24d2dd9-286f-4e1b-bb21-67987b923544	\N	private	\N	Привет	2025-12-29 07:05:57.85+03	e00edd24-c594-4947-a10b-0c1decc45879	2025-12-28 15:29:57.168+03	2025-12-29 07:05:57.85+03
dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	Тестовая группа	group	uploads/chat-avatars/chat-dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad-1767039129922-processed.jpg	Спасибо за информацию!	2025-12-28 16:22:55.426+03	e00edd24-c594-4947-a10b-0c1decc45879	2025-12-28 16:04:11.389+03	2025-12-29 23:12:09.945+03
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media (id, filename, "originalName", "mimeType", size, path, "thumbnailPath", alt, description, "createdAt", "updatedAt", "uploadedBy") FROM stdin;
8d2c8c80-873c-4eed-a579-10ae294b116a	a1e2388d-32aa-4b79-b9ff-04f4139e1cea.jpg	photo_2024-06-16_19-47-11.jpg	image/jpeg	111662	uploads/2025-12/a1e2388d-32aa-4b79-b9ff-04f4139e1cea.jpg	uploads/2025-12/thumbs/thumb_a1e2388d-32aa-4b79-b9ff-04f4139e1cea.jpg	\N	\N	2025-12-28 15:47:21.37+03	2025-12-28 15:47:21.37+03	e00edd24-c594-4947-a10b-0c1decc45879
2547dc2f-36a0-4cea-81a2-bacd3c45053e	8e9d7ff4-762c-43cd-abfd-3ab8af5dde36.jpg	photo_2025-11-07_16-16-08.jpg	image/jpeg	123842	uploads/2025-12/8e9d7ff4-762c-43cd-abfd-3ab8af5dde36.jpg	uploads/2025-12/thumbs/thumb_8e9d7ff4-762c-43cd-abfd-3ab8af5dde36.jpg	\N	\N	2025-12-28 16:09:43.443+03	2025-12-28 16:09:43.443+03	e00edd24-c594-4947-a10b-0c1decc45879
80623c74-ec67-4ba5-a3a3-bdd471d2fa78	a3b80ff8-266f-4777-be31-5e2092fb7316.jpg	ÐÑÐµÐ·ÐµÐ½ÑÐ°ÑÐ¸Ñ1.jpg	image/jpeg	122583	uploads/2025-12/a3b80ff8-266f-4777-be31-5e2092fb7316.jpg	uploads/2025-12/thumbs/thumb_a3b80ff8-266f-4777-be31-5e2092fb7316.jpg	\N	\N	2025-12-28 16:11:11.274+03	2025-12-28 16:11:11.274+03	e00edd24-c594-4947-a10b-0c1decc45879
9bd1a0cd-7180-4448-a93b-a3eaa4d3200c	be88abfd-94c6-4913-a8d6-77799ccca68c.pdf	ÐÐ°Ð½Ð½ÑÐµ Ð´Ð»Ñ Ð²ÑÐ¾Ð´Ð°.pdf	application/pdf	131296	uploads/2025-12/be88abfd-94c6-4913-a8d6-77799ccca68c.pdf	\N	\N	\N	2025-12-28 16:11:26.56+03	2025-12-28 16:11:26.56+03	e00edd24-c594-4947-a10b-0c1decc45879
628a58ba-7570-496b-9991-a151d685815a	229dee48-eabe-4eb3-8499-b55c33f9ee6e.jpg	photo_2024-06-16_19-47-11(1).jpg	image/jpeg	218722	uploads/2025-12/229dee48-eabe-4eb3-8499-b55c33f9ee6e.jpg	uploads/2025-12/thumbs/thumb_229dee48-eabe-4eb3-8499-b55c33f9ee6e.jpg	\N	\N	2025-12-28 16:18:53.827+03	2025-12-28 16:18:53.827+03	40817c24-c657-4d2a-90ed-d5d4b016bd58
ed0ae4d9-d4f9-4062-8402-23248af6869d	be1bc054-ec3f-46df-bfe3-e7be8dac4dd5.jpg	photo_2025-11-16_20-41-56.jpg	image/jpeg	59686	uploads/2025-12/be1bc054-ec3f-46df-bfe3-e7be8dac4dd5.jpg	uploads/2025-12/thumbs/thumb_be1bc054-ec3f-46df-bfe3-e7be8dac4dd5.jpg	\N	\N	2025-12-28 16:21:50.056+03	2025-12-28 16:21:50.056+03	e00edd24-c594-4947-a10b-0c1decc45879
c43e9c7b-b971-45cf-8669-757f7ceca2c1	76c78fea-1060-4dae-a2c9-f5346481df0b.jpg	photo_2024-06-16_19-47-11(1).jpg	image/jpeg	218722	uploads/2025-12/76c78fea-1060-4dae-a2c9-f5346481df0b.jpg	uploads/2025-12/thumbs/thumb_76c78fea-1060-4dae-a2c9-f5346481df0b.jpg	\N	\N	2025-12-28 16:22:13.927+03	2025-12-28 16:22:13.927+03	9ce0c786-8eac-4103-8ec3-e1535de838d7
1fc1e016-5034-4f54-9d7a-8adb6fc78ddc	d03d4191-6004-427b-a839-424daab5455c.jpg	photo_2025-11-07_16-16-08.jpg	image/jpeg	123842	uploads/2025-12/d03d4191-6004-427b-a839-424daab5455c.jpg	uploads/2025-12/thumbs/thumb_d03d4191-6004-427b-a839-424daab5455c.jpg	\N	\N	2025-12-28 16:22:39.952+03	2025-12-28 16:22:39.952+03	9ce0c786-8eac-4103-8ec3-e1535de838d7
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, "chatId", "senderId", content, type, attachments, "isEdited", "replyToId", "createdAt", "updatedAt") FROM stdin;
65c6e9ca-3721-4897-8a85-2e9bfc17a2de	c24d2dd9-286f-4e1b-bb21-67987b923544	e00edd24-c594-4947-a10b-0c1decc45879	Добрый день!	text	[]	f	\N	2025-12-28 15:30:06.477+03	2025-12-28 15:30:06.477+03
2e2d4409-62ce-4ebc-9bd7-add61d4d6e4a	c24d2dd9-286f-4e1b-bb21-67987b923544	40817c24-c657-4d2a-90ed-d5d4b016bd58	Здравствуйте!	text	[]	f	\N	2025-12-28 15:36:27.086+03	2025-12-28 15:36:27.086+03
992e622b-53c3-4f8c-a71a-a7e2eeef5cd2	dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	e00edd24-c594-4947-a10b-0c1decc45879	Администратор создал группу "Тестовая группа"	system	[]	f	\N	2025-12-28 16:04:11.442+03	2025-12-28 16:04:11.442+03
684e038c-5386-4c94-aa65-a5465f7ece8d	dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	e00edd24-c594-4947-a10b-0c1decc45879	Привет всем!	text	[]	f	\N	2025-12-28 16:04:29.226+03	2025-12-28 16:04:29.226+03
2c3da394-d72f-4f29-b586-18742fb61122	dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	e00edd24-c594-4947-a10b-0c1decc45879	test2 добавлен в группу	system	[]	f	\N	2025-12-28 16:05:58.957+03	2025-12-28 16:05:58.957+03
58a8e14e-dd86-463e-b93f-18f60ddc9394	dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	9ce0c786-8eac-4103-8ec3-e1535de838d7	Привет	text	[]	f	\N	2025-12-28 16:06:15.359+03	2025-12-28 16:06:15.359+03
b1eb511f-0ac7-44a5-8461-a9827f21e12c	dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	40817c24-c657-4d2a-90ed-d5d4b016bd58	Привет	text	[]	f	\N	2025-12-28 16:06:30.924+03	2025-12-28 16:06:30.924+03
effeb1d6-df3a-40c3-b006-14b0caefcea0	dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	e00edd24-c594-4947-a10b-0c1decc45879	📎 1 файл(ов)	image	[{"id": "80623c74-ec67-4ba5-a3a3-bdd471d2fa78", "url": "http://localhost:5000/uploads/2025-12/a3b80ff8-266f-4777-be31-5e2092fb7316.jpg", "name": "ÐÑÐµÐ·ÐµÐ½ÑÐ°ÑÐ¸Ñ1.jpg", "path": "uploads/2025-12/a3b80ff8-266f-4777-be31-5e2092fb7316.jpg", "size": 122583, "mimeType": "image/jpeg", "thumbnailUrl": "http://localhost:5000/uploads/2025-12/thumbs/thumb_a3b80ff8-266f-4777-be31-5e2092fb7316.jpg", "thumbnailPath": "uploads/2025-12/thumbs/thumb_a3b80ff8-266f-4777-be31-5e2092fb7316.jpg"}]	f	\N	2025-12-28 16:11:12.682+03	2025-12-28 16:11:12.682+03
d2aca360-31e5-43a1-a108-5efa0e8a314f	c24d2dd9-286f-4e1b-bb21-67987b923544	e00edd24-c594-4947-a10b-0c1decc45879	📎 1 файл(ов)	file	[{"id": "9bd1a0cd-7180-4448-a93b-a3eaa4d3200c", "url": "http://localhost:5000/uploads/2025-12/be88abfd-94c6-4913-a8d6-77799ccca68c.pdf", "name": "ÐÐ°Ð½Ð½ÑÐµ Ð´Ð»Ñ Ð²ÑÐ¾Ð´Ð°.pdf", "path": "uploads/2025-12/be88abfd-94c6-4913-a8d6-77799ccca68c.pdf", "size": 131296, "mimeType": "application/pdf", "thumbnailUrl": null, "thumbnailPath": null}]	f	\N	2025-12-28 16:11:28.649+03	2025-12-28 16:11:28.649+03
df699354-8604-43cb-bc0d-b611f2271a04	dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	9ce0c786-8eac-4103-8ec3-e1535de838d7	Спасибо за информацию!	text	[]	f	\N	2025-12-28 16:22:55.424+03	2025-12-28 16:22:55.424+03
8fb733bf-dcd5-4448-89fa-5f48f432e493	dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	9ce0c786-8eac-4103-8ec3-e1535de838d7	Грудинкина Марина покинул группу	system	[]	f	\N	2025-12-28 16:23:53.021+03	2025-12-28 16:23:53.021+03
ff9b7239-7cf5-4eb2-a536-8372e22d355e	dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	e00edd24-c594-4947-a10b-0c1decc45879	Грудинкина Марина добавлен в группу	system	[]	f	\N	2025-12-28 16:24:08.097+03	2025-12-28 16:24:08.097+03
f0fbeb7e-db93-4705-8b6d-e047da98ad0b	dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	e00edd24-c594-4947-a10b-0c1decc45879	Юдина Виктория исключён из группы	system	[]	f	\N	2025-12-29 01:02:01.351+03	2025-12-29 01:02:01.351+03
7efa4a96-78ca-4bc4-80de-0abc19311a11	dfef921e-1e2e-46fe-8bbf-7bd6a1c213ad	e00edd24-c594-4947-a10b-0c1decc45879	Юдина Виктория добавлен в группу	system	[]	f	\N	2025-12-29 01:02:06.615+03	2025-12-29 01:02:06.615+03
a8a8944a-23a2-41c3-8c21-1c242326230c	c24d2dd9-286f-4e1b-bb21-67987b923544	e00edd24-c594-4947-a10b-0c1decc45879	Привет	text	[]	f	\N	2025-12-29 07:05:28.557+03	2025-12-29 07:05:28.557+03
957d970a-8a68-4809-91b0-93837622400b	c24d2dd9-286f-4e1b-bb21-67987b923544	40817c24-c657-4d2a-90ed-d5d4b016bd58	Привет	text	[]	f	\N	2025-12-29 07:05:57.809+03	2025-12-29 07:05:57.809+03
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pages (id, slug, title, content, "contentType", description, keywords, "searchContent", icon, "isPublished", "isFavorite", "allowedRoles", "customCss", "customJs", metadata, "createdAt", "updatedAt", "createdBy", "updatedBy") FROM stdin;
3a174ec9-5cbb-4a22-a26e-59d296df4907	welcome	Тест	<p>п</p>	wysiwyg	Главная страница базы знаний	{главная,welcome,начало}	п	\N	t	t	{}			{}	2025-12-28 09:37:17.672+03	2025-12-29 01:24:17.324+03	e00edd24-c594-4947-a10b-0c1decc45879	e00edd24-c594-4947-a10b-0c1decc45879
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, description, permissions, "isSystem", "createdAt", "updatedAt") FROM stdin;
9eb724ce-e202-4844-85b6-12a5d5d4d5ab	Администратор	Полный доступ ко всем функциям системы	{"media": {"read": true, "delete": true, "upload": true}, "pages": {"read": true, "admin": true, "write": true, "delete": true}, "users": {"read": true, "write": true, "delete": true}, "settings": {"read": true, "write": true}}	t	2025-12-28 09:37:17.275+03	2025-12-28 09:37:17.275+03
0c859951-8de9-453d-a62d-387d5bd3dcd6	Регистратор	Только просмотр страниц	{"media": {"read": true, "delete": true, "upload": true}, "pages": {"read": true, "admin": false, "write": false, "delete": false}, "users": {"read": false, "write": false, "delete": false}, "settings": {"read": false, "write": false}}	f	2025-12-28 09:37:17.29+03	2025-12-28 16:18:23.311+03
ffd940b8-8606-4eb8-b5f9-f65e328d38d1	Маркетолог	Создание и редактирование страниц	{"media": {"read": true, "delete": false, "upload": true}, "pages": {"read": true, "admin": false, "write": true, "delete": false}, "users": {"read": false, "write": false, "delete": false}, "settings": {"read": false, "write": false}}	f	2025-12-28 09:37:17.287+03	2025-12-28 16:18:36.821+03
\.


--
-- Data for Name: search_index; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.search_index (id, "entityType", "entityId", title, content, keywords, url, metadata, "createdAt", "updatedAt") FROM stdin;
34139088-cf74-4721-a6d7-5470f840c408	page	3a174ec9-5cbb-4a22-a26e-59d296df4907	Тест	п	{главная,welcome,начало}	/page/welcome	{}	2025-12-28 10:49:54.884+03	2025-12-29 01:24:15.139+03
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (key, value, description, "createdAt", "updatedAt") FROM stdin;
accentColor	"#5856D6"	Акцентный цвет	2025-12-28 09:37:17.66+03	2025-12-28 09:37:17.66+03
primaryColor	"#007AFF"	Основной цвет	2025-12-28 09:37:17.659+03	2025-12-29 01:12:34.757+03
siteName	"Alfa Wiki"	Название сайта	2025-12-28 09:37:17.654+03	2025-12-28 11:45:48.039+03
siteDescription	"База знаний медицинского центра"	Описание сайта	2025-12-28 09:37:17.657+03	2025-12-28 11:45:48.079+03
logo	""	URL логотипа	2025-12-28 09:37:17.661+03	2025-12-28 11:45:48.081+03
defaultRole	"0c859951-8de9-453d-a62d-387d5bd3dcd6"	Роль по умолчанию	2025-12-28 09:37:17.663+03	2025-12-28 11:45:48.082+03
allowRegistration	false	Разрешить регистрацию	2025-12-28 09:37:17.664+03	2025-12-28 11:45:48.083+03
\.


--
-- Data for Name: sidebar_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sidebar_items (id, type, title, icon, "pageId", "externalUrl", "parentId", "sortOrder", "isExpanded", "allowedRoles", "isVisible", "createdAt", "updatedAt") FROM stdin;
6adb777f-0d5d-4405-bd65-dcec1ed36ea0	page	Test	heart	3a174ec9-5cbb-4a22-a26e-59d296df4907		\N	0	f	{0c859951-8de9-453d-a62d-387d5bd3dcd6}	t	2025-12-28 09:49:44.219+03	2025-12-28 19:19:56.244+03
1bdcfdaf-ff1e-48e0-aad9-b626156d61eb	divider	Разделы	\N	\N	\N	\N	1	f	{}	t	2025-12-28 09:37:17.683+03	2025-12-28 19:19:56.298+03
b5add393-81ec-4097-89f3-d40194dd6807	page	Главная	heart	3a174ec9-5cbb-4a22-a26e-59d296df4907		\N	2	f	{}	t	2025-12-28 09:37:17.68+03	2025-12-29 01:25:08.913+03
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, "displayName", email, avatar, "isActive", "isAdmin", "lastLogin", settings, "createdAt", "updatedAt", "roleId") FROM stdin;
e00edd24-c594-4947-a10b-0c1decc45879	admin	$2a$12$tws1nuv9P7itLgcLfINy/eSApDsN6tHzmLGIKxsbhf9UUbNuuPkdW	Стеценко Виталий	admin@example.com	http://localhost:5000/uploads/2025-12/be1bc054-ec3f-46df-bfe3-e7be8dac4dd5.jpg	t	t	2025-12-29 19:47:50.254+03	{}	2025-12-28 09:37:17.612+03	2025-12-29 19:47:50.254+03	9eb724ce-e202-4844-85b6-12a5d5d4d5ab
9ce0c786-8eac-4103-8ec3-e1535de838d7	test2	$2a$12$OZiP7heQ.G9WylVHr1mDWuVHBz0l6Tw5ywh2NJ08BG1t31VMKEUGq	Грудинкина Марина	test2@gmail.com	http://localhost:5000/uploads/2025-12/d03d4191-6004-427b-a839-424daab5455c.jpg	t	f	2025-12-28 16:22:03.938+03	{}	2025-12-28 16:04:55.04+03	2025-12-28 16:22:41.153+03	0c859951-8de9-453d-a62d-387d5bd3dcd6
40817c24-c657-4d2a-90ed-d5d4b016bd58	test	$2a$12$uuw9/ZnahGj1ug8UNNutk.RJpxOPL7Z14Dqxj6n/p4aezrHS7v1U.	Юдина Виктория	test@gamil.com	http://localhost:5000/uploads/2025-12/229dee48-eabe-4eb3-8499-b55c33f9ee6e.jpg	t	f	2025-12-29 07:07:47.099+03	{}	2025-12-28 15:01:01.402+03	2025-12-29 07:07:47.099+03	0c859951-8de9-453d-a62d-387d5bd3dcd6
\.


--
-- Name: chat_members chat_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_pkey PRIMARY KEY (id);


--
-- Name: chats chats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT chats_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: pages pages_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key UNIQUE (slug);


--
-- Name: pages pages_slug_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key1 UNIQUE (slug);


--
-- Name: pages pages_slug_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key10 UNIQUE (slug);


--
-- Name: pages pages_slug_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key11 UNIQUE (slug);


--
-- Name: pages pages_slug_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key12 UNIQUE (slug);


--
-- Name: pages pages_slug_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key13 UNIQUE (slug);


--
-- Name: pages pages_slug_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key14 UNIQUE (slug);


--
-- Name: pages pages_slug_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key15 UNIQUE (slug);


--
-- Name: pages pages_slug_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key16 UNIQUE (slug);


--
-- Name: pages pages_slug_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key17 UNIQUE (slug);


--
-- Name: pages pages_slug_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key18 UNIQUE (slug);


--
-- Name: pages pages_slug_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key19 UNIQUE (slug);


--
-- Name: pages pages_slug_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key2 UNIQUE (slug);


--
-- Name: pages pages_slug_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key20 UNIQUE (slug);


--
-- Name: pages pages_slug_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key21 UNIQUE (slug);


--
-- Name: pages pages_slug_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key22 UNIQUE (slug);


--
-- Name: pages pages_slug_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key23 UNIQUE (slug);


--
-- Name: pages pages_slug_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key24 UNIQUE (slug);


--
-- Name: pages pages_slug_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key25 UNIQUE (slug);


--
-- Name: pages pages_slug_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key26 UNIQUE (slug);


--
-- Name: pages pages_slug_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key27 UNIQUE (slug);


--
-- Name: pages pages_slug_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key28 UNIQUE (slug);


--
-- Name: pages pages_slug_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key29 UNIQUE (slug);


--
-- Name: pages pages_slug_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key3 UNIQUE (slug);


--
-- Name: pages pages_slug_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key30 UNIQUE (slug);


--
-- Name: pages pages_slug_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key31 UNIQUE (slug);


--
-- Name: pages pages_slug_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key4 UNIQUE (slug);


--
-- Name: pages pages_slug_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key5 UNIQUE (slug);


--
-- Name: pages pages_slug_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key6 UNIQUE (slug);


--
-- Name: pages pages_slug_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key7 UNIQUE (slug);


--
-- Name: pages pages_slug_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key8 UNIQUE (slug);


--
-- Name: pages pages_slug_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key9 UNIQUE (slug);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_name_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key1 UNIQUE (name);


--
-- Name: roles roles_name_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key10 UNIQUE (name);


--
-- Name: roles roles_name_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key11 UNIQUE (name);


--
-- Name: roles roles_name_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key12 UNIQUE (name);


--
-- Name: roles roles_name_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key13 UNIQUE (name);


--
-- Name: roles roles_name_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key14 UNIQUE (name);


--
-- Name: roles roles_name_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key15 UNIQUE (name);


--
-- Name: roles roles_name_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key16 UNIQUE (name);


--
-- Name: roles roles_name_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key17 UNIQUE (name);


--
-- Name: roles roles_name_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key18 UNIQUE (name);


--
-- Name: roles roles_name_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key19 UNIQUE (name);


--
-- Name: roles roles_name_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key2 UNIQUE (name);


--
-- Name: roles roles_name_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key20 UNIQUE (name);


--
-- Name: roles roles_name_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key21 UNIQUE (name);


--
-- Name: roles roles_name_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key22 UNIQUE (name);


--
-- Name: roles roles_name_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key23 UNIQUE (name);


--
-- Name: roles roles_name_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key24 UNIQUE (name);


--
-- Name: roles roles_name_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key25 UNIQUE (name);


--
-- Name: roles roles_name_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key26 UNIQUE (name);


--
-- Name: roles roles_name_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key27 UNIQUE (name);


--
-- Name: roles roles_name_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key28 UNIQUE (name);


--
-- Name: roles roles_name_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key29 UNIQUE (name);


--
-- Name: roles roles_name_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key3 UNIQUE (name);


--
-- Name: roles roles_name_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key30 UNIQUE (name);


--
-- Name: roles roles_name_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key31 UNIQUE (name);


--
-- Name: roles roles_name_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key4 UNIQUE (name);


--
-- Name: roles roles_name_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key5 UNIQUE (name);


--
-- Name: roles roles_name_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key6 UNIQUE (name);


--
-- Name: roles roles_name_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key7 UNIQUE (name);


--
-- Name: roles roles_name_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key8 UNIQUE (name);


--
-- Name: roles roles_name_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key9 UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: search_index search_index_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_index
    ADD CONSTRAINT search_index_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key);


--
-- Name: sidebar_items sidebar_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sidebar_items
    ADD CONSTRAINT sidebar_items_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: users users_username_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key1 UNIQUE (username);


--
-- Name: users users_username_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key10 UNIQUE (username);


--
-- Name: users users_username_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key11 UNIQUE (username);


--
-- Name: users users_username_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key12 UNIQUE (username);


--
-- Name: users users_username_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key13 UNIQUE (username);


--
-- Name: users users_username_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key14 UNIQUE (username);


--
-- Name: users users_username_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key15 UNIQUE (username);


--
-- Name: users users_username_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key16 UNIQUE (username);


--
-- Name: users users_username_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key17 UNIQUE (username);


--
-- Name: users users_username_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key18 UNIQUE (username);


--
-- Name: users users_username_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key19 UNIQUE (username);


--
-- Name: users users_username_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key2 UNIQUE (username);


--
-- Name: users users_username_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key20 UNIQUE (username);


--
-- Name: users users_username_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key21 UNIQUE (username);


--
-- Name: users users_username_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key22 UNIQUE (username);


--
-- Name: users users_username_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key23 UNIQUE (username);


--
-- Name: users users_username_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key24 UNIQUE (username);


--
-- Name: users users_username_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key25 UNIQUE (username);


--
-- Name: users users_username_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key26 UNIQUE (username);


--
-- Name: users users_username_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key27 UNIQUE (username);


--
-- Name: users users_username_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key28 UNIQUE (username);


--
-- Name: users users_username_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key29 UNIQUE (username);


--
-- Name: users users_username_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key3 UNIQUE (username);


--
-- Name: users users_username_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key30 UNIQUE (username);


--
-- Name: users users_username_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key31 UNIQUE (username);


--
-- Name: users users_username_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key4 UNIQUE (username);


--
-- Name: users users_username_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key5 UNIQUE (username);


--
-- Name: users users_username_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key6 UNIQUE (username);


--
-- Name: users users_username_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key7 UNIQUE (username);


--
-- Name: users users_username_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key8 UNIQUE (username);


--
-- Name: users users_username_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key9 UNIQUE (username);


--
-- Name: chat_members_chat_id_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX chat_members_chat_id_user_id ON public.chat_members USING btree ("chatId", "userId");


--
-- Name: pages_keywords; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages_keywords ON public.pages USING btree (keywords);


--
-- Name: pages_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages_slug ON public.pages USING btree (slug);


--
-- Name: pages_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages_title ON public.pages USING btree (title);


--
-- Name: search_index_entity_type_entity_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX search_index_entity_type_entity_id ON public.search_index USING btree ("entityType", "entityId");


--
-- Name: search_index_keywords; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX search_index_keywords ON public.search_index USING btree (keywords);


--
-- Name: chat_members chat_members_chatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT "chat_members_chatId_fkey" FOREIGN KEY ("chatId") REFERENCES public.chats(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_members chat_members_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT "chat_members_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE;


--
-- Name: media media_uploadedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT "media_uploadedBy_fkey" FOREIGN KEY ("uploadedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: messages messages_chatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_chatId_fkey" FOREIGN KEY ("chatId") REFERENCES public.chats(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_replyToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_replyToId_fkey" FOREIGN KEY ("replyToId") REFERENCES public.messages(id) ON UPDATE CASCADE;


--
-- Name: messages messages_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public.users(id) ON UPDATE CASCADE;


--
-- Name: pages pages_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT "pages_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: pages pages_updatedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT "pages_updatedBy_fkey" FOREIGN KEY ("updatedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sidebar_items sidebar_items_pageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sidebar_items
    ADD CONSTRAINT "sidebar_items_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES public.pages(id) ON UPDATE CASCADE;


--
-- Name: sidebar_items sidebar_items_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sidebar_items
    ADD CONSTRAINT "sidebar_items_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.sidebar_items(id) ON UPDATE CASCADE;


--
-- Name: users users_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict Dsh2kydzJVfAbu7bXuR01952hVPkLiaT1sPhwnRZmGSKYbZvGW1ErtVppCt4kc6

